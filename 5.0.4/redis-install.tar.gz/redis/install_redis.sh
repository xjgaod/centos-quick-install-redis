#!/bin/bash

function redis_install() {

redis=172.19.129.20
redisremote=root@172.19.129.20
 
genSshKeys;
pushKeys $redisremote

scp /opt/redis/redis-mkist-5.0.4-tar.gz $redisremote:/opt

ssh -tt $redisremote << remotessh
    mv  /opt/redis-mkist-5.0.4-tar.gz /usr/local/
    cd /usr/local/
	tar -zxvf redis-mkist-5.0.4-tar.gz redis/
	rm -rf /usr/local/bin/redis-server
	cp /usr/local/redis/bin/redis-server /usr/local/bin/
	firewall-cmd --zone=public --add-port=6379/tcp --permanent
	systemctl restart firewalld
	redis-server /usr/local/redis/etc/redis.conf
	rm -rf /usr/local/bin/redis-cli
	cp /usr/local/redis/bin/redis-cli /usr/local/bin/
	exit
remotessh
echo "redis is installed"
}


function genSshKeys() {
  if [ ! -e ~/.ssh/id_rsa ];then
    ssh-keygen -t rsa
  fi
}


function pushKeys() {
  echo "push keys to remote node:" $1
  remote=$1
  cat ~/.ssh/id_rsa.pub | ssh $remote "
    mkdir -p ~/.ssh
    chmod 700 ~/.ssh
    cat >> ~/.ssh/authorized_keys
    sort -u ~/.ssh/authorized_keys > ~/.ssh/authorized_keys.bak
    mv ~/.ssh/authorized_keys.bak ~/.ssh/authorized_keys
    chmod 600 ~/.ssh/authorized_keys
  "
  ssh -n -o PasswordAuthentication=no $remote true
}
redis_install
